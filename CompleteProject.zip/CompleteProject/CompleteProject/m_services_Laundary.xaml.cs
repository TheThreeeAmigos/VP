﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_services_Laundary.xaml
    /// </summary>
    public partial class m_services_Laundary : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        int id = 0;

        string u_name ="";
        public m_services_Laundary()
        {
            InitializeComponent();
            var x = from y in db.Customers
                    select y.Id;
            combobox.ItemsSource = x;
        }
        public m_services_Laundary(string s)
        {
            u_name = s;
            InitializeComponent();
            var x = from y in db.Customers
                    select y.Id;
            combobox.ItemsSource = x;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            id = int.Parse(combobox.SelectedItem.ToString());

            m_laundaryUpdate win = new m_laundaryUpdate(id,u_name);
            win.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            m_mainServices win = new m_mainServices(u_name);
            win.Show();
            this.Close();
        }
    }
}
