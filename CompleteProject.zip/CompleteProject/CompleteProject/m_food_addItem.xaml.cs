﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_food_addItem.xaml
    /// </summary>
    public partial class m_food_addItem : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        enum FoodCategory { Breakfast, Lunch, Dinner };

        struct Food_Category
        {

            FoodCategory foood;

            public Food_Category(FoodCategory Food)
            {

                this.foood = Food;

            }
        }
            string u_name="";
        public m_food_addItem()
        {
            InitializeComponent();
            combobox.ItemsSource = System.Enum.GetValues(typeof(FoodCategory));
        }
        public m_food_addItem(string s)
        {
            u_name = s;
            InitializeComponent();
            combobox.ItemsSource = System.Enum.GetValues(typeof(FoodCategory));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string fooditem = textbox1.Text;
            string price = textbox2.Text;
            string foodcategory = combobox.SelectedItem.ToString();

            Food f = new Food
            {
                Item = fooditem,
                Price = int.Parse(price),
                Type = foodcategory
            };
            db.Foods.InsertOnSubmit(f);
            db.SubmitChanges();
            var result = from x in db.Foods
                         select new
                         {
                             x.Id,
                             x.Type,
                             x.Item,
                             x.Price,

                         };
            dg.ItemsSource = result;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            m_foodServices win = new m_foodServices(u_name);
            win.Show();
            this.Close();
        }

    }
}
