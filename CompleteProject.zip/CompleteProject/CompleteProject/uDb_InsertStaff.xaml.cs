﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for uDb_InsertStaff.xaml
    /// </summary>
    public partial class uDb_InsertStaff : Window
    {
        public uDb_InsertStaff()
        {
            InitializeComponent();
        }

        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            string name = txt_Name.Text,
                 username = txt_Username.Text,
                 password = passwordBox.Password,
                 passwordConfirmation = passwordBox_Copy.Password,
                 privilege;

            if (rbtn_isAdmin.IsChecked == true)
            {
                privilege = "true";
            }
            else
            {
                privilege = "false";
            }

            Staff newMember = new Staff();

            if (txt_Name.Text != "")
            {
                if (txt_Username.Text != "")
                {
                    if (password != "")
                    {
                        if (password == passwordConfirmation)
                        {
                            registerUser(name, username, password, privilege);
                        }
                        else
                        {
                            MessageBox.Show("Password Mismatch");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please choose a password");
                    }
                }
                else
                {
                    MessageBox.Show("Please select a username");
                }
            }
            else
            {
                MessageBox.Show("Please insert a name");
            }

        }

        private void registerUser(string name, string username, string password, string privilege)
        {
            DataClasses1DataContext dc = new DataClasses1DataContext();

            Staff newStaff = new Staff();
            newStaff.Name = name;
            newStaff.Username = username;
            newStaff.Password = password;
            newStaff.Admin = privilege;

            dc.Staffs.InsertOnSubmit(newStaff);
            dc.SubmitChanges();
            this.Close();

            MessageBox.Show("Staff Member Added Successfully!");

        }
    }
}
