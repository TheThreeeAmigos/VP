﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_laundaryUpdate.xaml
    /// </summary>
    public partial class m_laundaryUpdate : Window
    {
        string u_name = "";
        DataClasses1DataContext db = new DataClasses1DataContext();
        int cid = 0;
        int sid = 0;
        int initiallaundary = 0;
        int initialnooftours = 0;
        public m_laundaryUpdate()
        {
            InitializeComponent();
        }
        public m_laundaryUpdate(int c_id,string s)
        {
            u_name = s;
            InitializeComponent();
            cid = c_id;

            var cus = from x in db.Customers
                      where x.Id == c_id
                      select x.Service_Id;

            sid = cus.FirstOrDefault().Value;

            var laundary = from servicedata in db.Services
                           where servicedata.Id == sid
                           select servicedata.NoOfLaundary;
            initiallaundary = laundary.FirstOrDefault().Value;
            nooflaundary.Text = laundary.FirstOrDefault().ToString();

            var nooftours = from servicedata in db.Services
                            where servicedata.Id == sid
                            select servicedata.NoOfTours;
            initialnooftours = nooftours.FirstOrDefault().Value;
            tour.Text = nooftours.FirstOrDefault().ToString();


        }
        private void dg3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            m_services_Laundary win = new m_services_Laundary(u_name);
            win.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            initiallaundary += 1;
            nooflaundary.Text = initiallaundary.ToString();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            initialnooftours += 1;
            tour.Text = initialnooftours.ToString();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Service s = db.Services.Single(Service => Service.Id == sid);
            {
                s.NoOfTours = initialnooftours;
                s.NoOfLaundary = initiallaundary;
                db.SubmitChanges();
            }

            var result = from x in db.Services
                         select new
                         {
                             ServiceID = x.Id,
                             x.NoOfLaundary,
                             x.NoOfTours
                         };
            dg.ItemsSource = result;
        }
    }
}
