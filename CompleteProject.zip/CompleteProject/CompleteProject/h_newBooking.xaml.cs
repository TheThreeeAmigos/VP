﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for h_newBooking.xaml
    /// </summary>
    public partial class h_newBooking : Window
    {
        string u_name = "";
        DataClasses1DataContext dc = new DataClasses1DataContext();
        public h_newBooking()
        {
            InitializeComponent();
        }
        public h_newBooking(string s)
        {
            u_name = s;
            InitializeComponent();
            var xyz = from x in dc.Rooms
                      where x.Availability.Contains("Yes")
                      select x.Id;
            comboBox1.ItemsSource = xyz;
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


        void CheckIn1_Click(object sender, RoutedEventArgs e)
        {
            //Room Availability
            Room r = dc.Rooms.Single(Room => Room.Id == int.Parse(comboBox1.SelectedValue.ToString()));
            {
                r.Availability = "No";
                dc.SubmitChanges();
            }

            Service ser = new Service
            {
                NoOfLaundary = 0,
                NoOfTours = 0
            };

            dc.Services.InsertOnSubmit(ser);
            dc.SubmitChanges();

            Bill billl = new Bill
            {
                Check_In_Date = Checkin.SelectedDate,
                Check_Out_Date = Checkout.SelectedDate,
                NoOfDays = int.Parse(NoOfDayStay.Text)
            };

            dc.Bills.InsertOnSubmit(billl);
            dc.SubmitChanges();


            //new Customer
            string Name = textBox1.Text;
            string ContactNo = textBox2.Text;

            Customer cus = new Customer
            {
                Name = Name,
                Contact = ContactNo,
                Service_Id = ser.Id,
                Room_Id = r.Id,
                Bill_Id = billl.Id
            };

            dc.Customers.InsertOnSubmit(cus);
            dc.SubmitChanges();

            var view1 = from ro in dc.Rooms
                        join c in dc.Customers on ro.Id equals c.Room_Id
                        select new
                        {
                            CustomerId = c.Id,
                            CustomerName = c.Name,
                            ContactNo = c.Contact,
                            RoomAssigned = ro.Id,
                            BillId = c.Bill_Id
                        };

            gridView.ItemsSource = view1;
        }

        private void CheckIn_Click(object sender, RoutedEventArgs e)
        {

            h_HotelData d = new h_HotelData(u_name);
            d.Show();
            this.Close();
        }

        private void backbtn_Click(object sender, RoutedEventArgs e)
        {
            adminwin win = new adminwin(u_name);
            win.Show();
            this.Close();
        }
    }
}
