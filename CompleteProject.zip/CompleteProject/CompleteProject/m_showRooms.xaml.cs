﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_showRooms.xaml
    /// </summary>
    public partial class m_showRooms : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        enum RoomCategory { ClassA, ClassB, ClassC };

        struct Room_Category
        {

            RoomCategory room;

            public Room_Category(RoomCategory Room)
            {

                this.room = Room;

            }

        }
        string u_name = "";
        public m_showRooms()
        {
            InitializeComponent();
            combobox1.ItemsSource = System.Enum.GetValues(typeof(RoomCategory));

        }
        public m_showRooms(string s)
        {
            InitializeComponent();
            u_name = s;
            combobox1.ItemsSource = System.Enum.GetValues(typeof(RoomCategory));

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string s = combobox1.SelectedItem.ToString();

            if (cbx.IsChecked == true)
            {
                var rooms = from x in db.Rooms
                            where x.Type.Contains(s) && x.Availability == "Yes"
                            select x;
                dg.ItemsSource = rooms;

            }
            else
            {
                var rooms = from x in db.Rooms
                            where x.Type.Contains(s)
                            select x;
                dg.ItemsSource = rooms;

            }
        }

        private void back(object sender, RoutedEventArgs e)
        {
            m_mainServices win = new m_mainServices(u_name);
            win.Show();
            this.Close();
        }
    }
}
