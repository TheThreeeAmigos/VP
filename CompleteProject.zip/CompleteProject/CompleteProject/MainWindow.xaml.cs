﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        public MainWindow()
        {
            InitializeComponent();

            var xyz = from x in db.Staffs
                      select x.Username;
            usernameBox.ItemsSource = xyz;


        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (usernameBox.SelectedItem != null)
            {
                var username = usernameBox.SelectedItem.ToString();
                var xyz = from x in db.Staffs
                          where x.Username.Contains(username)
                          select x.Password;
                if (xyz.FirstOrDefault() != passwordBox.Password)
                {
                    MessageBox.Show("Incorrect Password");

                }
                else
                {
                    var xyz1 = from x in db.Staffs
                               where x.Username.Contains(username)
                               select x.Admin;

                    if (xyz1.FirstOrDefault() == "yes")
                    {
                        adminwin adminPanel = new adminwin(usernameBox.Text);
                        adminPanel.Show();
                        this.Close();
                        MessageBox.Show("Welcome " + usernameBox.Text + " to Admin Panel");
                    }
                    else
                    {
                        staffwin staffPanel = new staffwin(usernameBox.Text);
                        staffPanel.Show();
                        this.Close();
                        MessageBox.Show("Welcome " + usernameBox.Text + " to Staff Panel");
                    }

                }
            }
            else //If Username is null
            {
                MessageBox.Show("Select a username");
            }
        }

        string password;

        private void showPassword_Click(object sender, RoutedEventArgs e)
        {
            if (showPassword.IsChecked == true)
            {


                passwordBox.Visibility = Visibility.Hidden;
                textBox.Visibility = Visibility.Visible;


                password = passwordBox.Password;
                textBox.Text = password;



                passwordBox.Focus();
            }
            else
            {

                if (passwordBox.Password == "")
                {
                    passwordBox.Visibility = Visibility.Visible;
                    textBox.Visibility = Visibility.Hidden;

                    password = textBox.Text;
                    passwordBox.Password = password;

                }
                else
                {
                    passwordBox.Visibility = Visibility.Visible;
                    textBox.Visibility = Visibility.Hidden;

                    textBox.Text = password;

                    passwordBox.Focus();
                }
            }
        }

    }
}
