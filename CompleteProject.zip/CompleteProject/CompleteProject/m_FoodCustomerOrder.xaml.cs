﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_FoodCustomerOrder.xaml
    /// </summary>
    public partial class m_FoodCustomerOrder : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        int id = 0;
        public m_FoodCustomerOrder()
        {
            InitializeComponent();
            var x = from y in db.Customers
                    select y.Id;
            id_box.ItemsSource = x;
            id = x.FirstOrDefault();
        }
        string u_name;
        public m_FoodCustomerOrder(string s)
        {
            u_name = s;
            InitializeComponent();
            var x = from y in db.Customers
                    select y.Id;
            id_box.ItemsSource = x;
            id = x.FirstOrDefault();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            id = int.Parse(id_box.SelectedItem.ToString());
            m_food_oder_itemSelect win = new m_food_oder_itemSelect(id,u_name);
            win.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            m_foodServices win = new m_foodServices(u_name);
            win.Show();
            this.Close();
        }
    }
}
