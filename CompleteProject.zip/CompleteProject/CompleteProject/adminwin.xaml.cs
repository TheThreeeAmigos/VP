﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for adminwin.xaml
    /// </summary>
    public partial class adminwin : Window
    {
        string u_name="";
        public adminwin()
        {
            InitializeComponent();
        }
        public adminwin(string username)
        {
            InitializeComponent();
            lbl_signedInAs.Content = "Signed in as: " + username;
            u_name = username;

        }
        DataClasses1DataContext dc;
        private void searchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchQuery = searchBox.Text.ToString();
            dc = new DataClasses1DataContext();

            /// <summary>
            /// General Search
            /// </summary>

            if (rbtn_CustomerName.IsChecked == true && (searchQuery == "Search" || searchQuery == ""))
            {

                var xyz = from x in dc.Customers
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                              
                          };

                dataGrid2.ItemsSource = xyz;
            }

            /// <summary>
            /// Search by Name
            /// </summary>
            else if (rbtn_CustomerName.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                var xyz = from x in dc.Customers
                          where x.Name.StartsWith(searchQuery)
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                             
                          };

                dataGrid2.ItemsSource = xyz;
            }

            /// <summary>
            /// Search by ID
            /// </summary>

            else if (rbtn_CustomerID2.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                int searchID = Int32.Parse(searchQuery);
                var xyz = from x in dc.Customers
                          where x.Id == searchID
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                            
                          };

                dataGrid2.ItemsSource = xyz;
            }

            /// <summary>
            /// Search by Room Number
            /// </summary>

            else if (rbtn_Room2.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                int searchRoom = Int32.Parse(searchQuery);
                var xyz = from x in dc.Customers
                          where x.Room_Id == searchRoom
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                             
                          };

                dataGrid2.ItemsSource = xyz;
            }

            /// <summary>
            /// Employee General Search
            /// </summary>

            else if (rbtn_EmployeeName.IsChecked == true && (searchQuery == "Search" || searchQuery == ""))
            {

                var xyz = from x in dc.Staffs
                          select new
                          {
                              StaffID = x.Id,
                              Name = x.Name,
                              Username = x.Username
                          };

                dataGrid2.ItemsSource = xyz;
            }

            /// <summary>
            /// Search Employee by Name
            /// </summary>
            /// 
            else if (rbtn_EmployeeName.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                var xyz = from x in dc.Staffs
                          where x.Name.StartsWith(searchQuery)
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Username = x.Username
                          };
                dataGrid2.ItemsSource = xyz;
            }
            else if (rbtn_EmployeeID.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                var xyz = from x in dc.Staffs
                          where x.Id == Int32.Parse(searchQuery)
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Username = x.Username
                          };
                dataGrid2.ItemsSource = xyz;
            }
        }
        private void btn_Bookings_Click(object sender, RoutedEventArgs e)       //hira's project
        {
            h_newBooking booking = new h_newBooking(u_name);
            booking.Show();
            this.Close();
        }

        private void btn_Billings_Click(object sender, RoutedEventArgs e)        //my project
        {
            a_billing bill = new a_billing(u_name);
            bill.Show();
            this.Close();

        }

        private void btn_Services_Click(object sender, RoutedEventArgs e)       //mohsin project
        {
            m_mainServices services = new m_mainServices(u_name);
            services.Show();
            this.Close();
        }

        private void btn_signOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow newForm = new MainWindow();
            newForm.Show();
            this.Close();
        }

        private void btn_update_Click(object sender, RoutedEventArgs e)
        {
            updateDatabase updateWindow = new updateDatabase();
            updateWindow.Show();
        }
    }
    }
