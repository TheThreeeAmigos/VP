﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for staffwin.xaml
    /// </summary>
    public partial class staffwin : Window
    {
        public staffwin()
        {
            InitializeComponent();
        }
        public staffwin(string username)
        {
            InitializeComponent();
            lbl_signedInAs.Content = "Signed in as: " + username;
        }
        DataClasses1DataContext dc;
        private void searchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchQuery = searchBox1.Text.ToString();
            dc = new DataClasses1DataContext();

            /// <summary>
            /// General Search
            /// </summary>

            if (rbtn_Name.IsChecked == true && (searchQuery == "Search" || searchQuery == ""))
            {

                var xyz = from x in dc.Customers
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                             
                          };

                dataGrid1.ItemsSource = xyz;
            }

            /// <summary>
            /// Search by Name
            /// </summary>
            else if (rbtn_Name.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                var xyz = from x in dc.Customers
                          where x.Name == searchQuery
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                             
                          };

                dataGrid1.ItemsSource = xyz;
            }


            /// <summary>
            /// Search by ID
            /// </summary>

            else if (rbtn_CustomerID.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                int searchID = Int32.Parse(searchQuery);
                var xyz = from x in dc.Customers
                          where x.Id == searchID
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                            
                          };

                dataGrid1.ItemsSource = xyz;
            }

            /// <summary>
            /// Search by Room Number
            /// </summary>

            else if (rbtn_Room.IsChecked == true && !(searchQuery == "Search" || searchQuery == ""))
            {
                int searchRoom = Int32.Parse(searchQuery);
                var xyz = from x in dc.Customers
                          where x.Room_Id == searchRoom
                          select new
                          {
                              ID = x.Id,
                              Name = x.Name,
                              Contact = x.Contact,
                              Service_ID = x.Service_Id,
                              Room_ID = x.Room_Id,
                              Bill_ID = x.Bill_Id,
                              
                          };

                dataGrid1.ItemsSource = xyz;
            }
        }
        /// <summary>
        /// Sign Out
        /// </summary>
        private void btn_signOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow newForm = new MainWindow();
            newForm.Show();
            this.Close();

        }
    }
}
