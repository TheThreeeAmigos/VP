﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_mainServices.xaml
    /// </summary>
    public partial class m_mainServices : Window
    {
        string u_name = "";
        public m_mainServices()
        {
            InitializeComponent();
        }
        public m_mainServices(string s)
        {
            u_name = s;
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            m_showRooms win = new m_showRooms(u_name);
            win.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            m_foodServices win = new m_foodServices(u_name);
            win.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
           m_services_Laundary win = new m_services_Laundary(u_name);
           
            win.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
           m_services_addRoom win = new m_services_addRoom(u_name);
            win.Show();
            this.Close();
        }

        private void Back(object sender, RoutedEventArgs e)
        {
            adminwin win = new adminwin(u_name);
            win.Show();
            this.Close();
        }
    }
}
