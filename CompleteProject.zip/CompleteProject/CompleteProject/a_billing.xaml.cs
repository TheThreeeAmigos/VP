﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for a_billing.xaml
    /// </summary>
    public partial class a_billing : Window
    {
        string u_name="";
        int cid = 0;
        DataClasses1DataContext db = new DataClasses1DataContext();
        public a_billing()
        {
            InitializeComponent();

            var _id = from x in db.Customers
                      select x.Id;
            id_box.ItemsSource = _id;
            id_box.SelectedValue = _id.FirstOrDefault();
        }
        public a_billing(string s)
        {
            InitializeComponent();
            u_name = s;
            var _id = from x in db.Customers
                      select x.Id;
            id_box.ItemsSource = _id;
            id_box.SelectedValue = _id.FirstOrDefault();
        }


        private void btn1_Click(object sender, RoutedEventArgs e)
        {

            cid = int.Parse(id_box.SelectedValue.ToString());
            a_genBill win = new a_genBill(cid,u_name);
            win.Show();
            this.Close();
        }

        private void btn1_Copy_Click(object sender, RoutedEventArgs e)
        {
            adminwin win = new adminwin(u_name);
            win.Show();
            this.Close();
        }
    }
}
