﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for updateDatabase.xaml
    /// </summary>
    public partial class updateDatabase : Window
    {
        public updateDatabase()
        {
            InitializeComponent();
        }
        private void btn_Next_Click(object sender, RoutedEventArgs e)
        {
            if (insertStaff.IsChecked == true)
            {
                uDb_InsertStaff uDb = new uDb_InsertStaff();
                uDb.Show();
                this.Close();
            }
            else if (deleteStaff.IsChecked == true)
            {
                uDb_DeleteStaff uDb = new uDb_DeleteStaff();
                uDb.Show();
                this.Close();
            }
            else if (insertStaff.IsChecked == false && deleteStaff.IsChecked == false)
            {
                MessageBox.Show("Please select an option");
            }
        }
    }
}
