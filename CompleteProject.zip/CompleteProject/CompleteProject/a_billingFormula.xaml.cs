﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for a_billingFormula.xaml
    /// </summary>
    public partial class a_billingFormula : Window
    {
        string u_name="";
        int foodtotal = 0;
        int laundarytotal = 0;
        int torutotal = 0;
        int room = 0;
        int grandtotal = 0;
        public a_billingFormula()
        {
            InitializeComponent();
        }
        public a_billingFormula(string s,int f,int r,int l,int t,int gt)
        {
     
            InitializeComponent();
            u_name = s;
            foodtotal = f;
            foodcharges.Content = foodtotal.ToString();
            laundarytotal = l;
            launcharges.Content = laundarytotal.ToString();
            room = r;
            roomcharges.Content = room.ToString();
            torutotal = t;
            tourcharges.Content = torutotal.ToString();
            grandtotal = gt;
            totalcharges.Content = grandtotal.ToString();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
            if (printDlg.ShowDialog() == true)
            {
                printDlg.PrintVisual(this, "WPF Print");
            }
        }
    }
}
