﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for uDb_DeleteStaff.xaml
    /// </summary>
    public partial class uDb_DeleteStaff : Window
    {
        DataClasses1DataContext dc = new DataClasses1DataContext();
        public uDb_DeleteStaff()
        {
            InitializeComponent();

            var xyz = from x in dc.Staffs
                      select x.Username;
            comboBox.ItemsSource = xyz;
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            var rowObj = from delete in dc.Staffs
                         where delete.Username == comboBox.Text
                         select delete;

            foreach (var x in rowObj)
            {
                dc.Staffs.DeleteOnSubmit(x);
            }

            dc.SubmitChanges();

            this.Close();
            MessageBox.Show("Deletion Successful");
        }
    }
}
