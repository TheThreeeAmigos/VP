﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for a_genBill.xaml
    /// </summary>
    public partial class a_genBill : Window
    {
        int foodtotal = 0;
        int laundarytotal = 0;
        int torutotal = 0;
        int roomcharges = 0;
        int grandtotal = 0;

        DateTime d_in;
        DateTime d_out;

        DataClasses1DataContext db = new DataClasses1DataContext();
        public a_genBill()
        {

            InitializeComponent();

        }
        string u_name="";
        public a_genBill(int id ,string s)
        {

            InitializeComponent();
            u_name = s;
            MessageBox.Show("Generating Bill For Customer id: " + id);
            var query = from x in db.Customers
                        where x.Id == id
                        select x;

            var result = query.FirstOrDefault();

            lbl_name.Content = result.Name;                         //Name
            lbl_cid.Content = result.Id;                            //customer id
            lbl_contact.Content = result.Contact;                   //contact
            lbl_roomid.Content = result.Room_Id;                    //room no
            lbl_roomType.Content = result.Room.Type;                //room type
            lbl_roomPrice.Content = result.Room.Price;              //room Price
            lbl_lau.Content = result.Service.NoOfLaundary;          //no of laundry service
            int nooflau = int.Parse(result.Service.NoOfLaundary.ToString());
            lbl_tou.Content = result.Service.NoOfTours;             //no of tour services
            int nooftou = int.Parse(result.Service.NoOfTours.ToString());


            var listfood = from x in db.CustFoods
                           where x.Customer_Id == id
                           select new
                           {
                               Item = x.Food.Item,
                               Price = x.Food.Price
                           };
            food_grid.ItemsSource = listfood;           //display food items with prices

            var pricelist = from x in db.CustFoods              // getting prices of items
                            where x.Customer_Id == id
                            select x.Food.Price;
            if (pricelist.FirstOrDefault().ToString() == "")
            {
                lbl_foodtotal.Content = "0";
                foodtotal = 0;
            }
            else
            {
                int intftotal = int.Parse(pricelist.Sum().ToString());          //food sum
                lbl_foodtotal.Content = intftotal.ToString();
                foodtotal = intftotal;

            }
            d_in = result.Bill.Check_In_Date.Value.Date;            //check in date
            date_in.SelectedDate = d_in;

            d_out = result.Bill.Check_Out_Date.Value.Date;
            date_out.SelectedDate = d_out;                  //check out date

            lbl_noofdays.Content = result.Bill.NoOfDays.ToString();
            int noofdays = int.Parse(result.Bill.NoOfDays.ToString());          //No of days
            lbl_billid.Content = result.Bill_Id.ToString();                     //bill id
            //-------------------------Calculatin grand total---------------------->
            int grand_total = 0;

            grand_total = grand_total + foodtotal;            //adding food total
            int roomtotal = int.Parse(result.Room.Price.ToString()) * noofdays;   //room charges for no of days stayed
            roomcharges = roomtotal;
            grand_total = grand_total + roomtotal;
            grand_total = grand_total + (300 * nooflau);       //each laundry service cost 300
            laundarytotal = 300 * nooflau;
            grand_total = grand_total + (500 * nooftou);       //each tour  service cost 500
            torutotal = 500 * nooftou;
            grandtotal = grand_total;
            //-------------------------grand total calculated------------------------>
            lbl_totalbill.Content = grand_total.ToString();
        }
        private void back_handler(object sender, RoutedEventArgs e)
        {
            a_billing win = new a_billing(u_name);
            win.Show();
            this.Close();
        }

        private void print_handler(object sender, RoutedEventArgs e)
        {
            PrintDialog printDlg = new System.Windows.Controls.PrintDialog();
            if (printDlg.ShowDialog() == true)
            {
                printDlg.PrintVisual(this, "WPF Print");
            }

        }

        private void printbtn_Copy_Click(object sender, RoutedEventArgs e) // billing formula
        {
            a_billingFormula win = new a_billingFormula(u_name,foodtotal,roomcharges,laundarytotal,torutotal,grandtotal);
            win.Show();
            
        }
    }
}
