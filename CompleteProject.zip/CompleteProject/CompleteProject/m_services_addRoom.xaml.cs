﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_services_addRoom.xaml
    /// </summary>
    public partial class m_services_addRoom : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        enum RoomCategory { ClassA, ClassB, ClassC };

        struct Room_Category
        {

            RoomCategory room;

            public Room_Category(RoomCategory Room)
            {

                this.room = Room;

            }

        }
        public m_services_addRoom()
        {
            InitializeComponent();
            combobox.ItemsSource = System.Enum.GetValues(typeof(RoomCategory));
        }
        string u_name="";

        public m_services_addRoom(string s)
        {
            u_name = s;

            InitializeComponent();
            combobox.ItemsSource = System.Enum.GetValues(typeof(RoomCategory));
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string type = combobox.SelectedValue.ToString();
            int pr = 0;
            if (type == "ClassA")
            {
                pr = 20000;

            }
            else if (type == "ClassB")
            {
                pr = 15000;

            }
            else if (type == "ClassC")
            {
                pr = 10000;

            }
            Room r = new Room
            {
                Availability = "Yes",
                Price = pr,
                Type = type
            };
            db.Rooms.InsertOnSubmit(r);
            db.SubmitChanges();
            var x = from y in db.Rooms
                    select y;
            dj.ItemsSource = x;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            m_mainServices win = new m_mainServices(u_name);
            win.Show();
            this.Close();
        }
    }
}
