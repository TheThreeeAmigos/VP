﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for m_food_oder_itemSelect.xaml
    /// </summary>
    public partial class m_food_oder_itemSelect : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();
        int cid;
        int fid;
        enum FoodTimings { Breakfast, Lunch, Dinner };

        struct Food_Timings
        {

            FoodTimings food;

            public Food_Timings(FoodTimings Food)
            {

                this.food = Food;

            }

        }
        public m_food_oder_itemSelect()
        {
            InitializeComponent();
        }
        string u_name="";
        public m_food_oder_itemSelect(int id, string s)
        {
            InitializeComponent();
            u_name = s;
            cid = id;
            InitializeComponent();
            combobox2.ItemsSource = System.Enum.GetValues(typeof(FoodTimings));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int startrange = int.Parse(s_range.Text);
            int endrange = int.Parse(e_range.Text);

            string s = combobox2.SelectedItem.ToString();

            var x = from y in db.Foods
                    where y.Price >= startrange && y.Price <= endrange && y.Type.Contains(s)
                    select new
                    {
                        Item = y.Item,
                        Price = y.Price

                    };

            gd2.ItemsSource = x;

            selecteditem.ItemsSource = x;
            var x1 = from y in db.Foods
                     where y.Price >= startrange && y.Price <= endrange && y.Type.Contains(s)
                     select y.Id;

            hidden.ItemsSource = x1;

            int xyz = selecteditem.SelectedIndex;


        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            m_FoodCustomerOrder win = new m_FoodCustomerOrder(u_name);
            win.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("" + fid);

        }

        private void order(object sender, RoutedEventArgs e)
        {

            hidden.SelectedIndex = selecteditem.SelectedIndex;
            //   MessageBox.Show(""+hidden.SelectedItem.ToString());
            fid = int.Parse(hidden.SelectedItem.ToString());
            //    MessageBox.Show("Customer id : " + cid+" Food id : "+ fid);
            CustFood cf = new CustFood
            {
                Customer_Id = cid,
                Food_Id = fid
            };
            db.CustFoods.InsertOnSubmit(cf);
            db.SubmitChanges();

            MessageBox.Show("Order has been placed");

        }

        private void combobox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void selecteditem_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
