﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CompleteProject
{
    /// <summary>
    /// Interaction logic for h_HotelData.xaml
    /// </summary>
    public partial class h_HotelData : Window
    {
        string u_name = "";
        DataClasses1DataContext dc = new DataClasses1DataContext();
        public h_HotelData()
        {
            InitializeComponent();
        }
        public h_HotelData(string s)
        {
            u_name = s;
            InitializeComponent();
            var info = from c in dc.Customers
                       select c.Name;
            comboBox1.ItemsSource = info;
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            h_newBooking win = new h_newBooking(u_name);
            win.Show();
            this.Close();
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
    
            var show = from c in dc.Customers
                       where c.Name == comboBox1.SelectedItem.ToString()
                       select new
                       {
                           Name = c.Name,
                           Contact = c.Contact,
                           No_Of_Laundary = c.Service.NoOfLaundary,
                           No_Of_Tour = c.Service.NoOfTours,
                           Bill_id = c.Bill_Id
                       };
            gridView.ItemsSource = show;
        }
    }
}
